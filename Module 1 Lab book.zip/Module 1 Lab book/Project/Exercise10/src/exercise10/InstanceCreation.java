package exercise10;
interface InstanceId{
	int id();
}
interface InstanceName{
	String name();
}
class A{
	int id;
	String name;
	
	public A(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "InstanceCreation [id=" + id + ", name=" + name + "]";
	}
}
public class InstanceCreation {

	public static void main(String[] args) {
		A o=new A(32,"archana");
		
		InstanceId i2=o::getId;
		System.out.println(i2.id());
		InstanceName i1=o::getName;
		System.out.println(i1.name());
	}

}



