package exercise6.com;
import java.io.File;
import java.io.File;


public class DisplayInformation {
	public static void main(String[] args) {
		File f=new File("Excuseme.txt");
		if(f.exists()){
			System.out.println(f.getName()+  " exists");
			System.out.println("file is " +f.length()  + " bytes");
			if(f.canRead())
		  System.out.println("readable");
			else
				System.out.println("not readable");
			if(f.canWrite())
				System.out.println("writable");
			else
				System.out.println("not writable");
			if(f.isFile())
				System.out.println("normal file");
		}
}
}

