abstract class Item {
	 int id;
	 String title;
	 int noOfCopies;
	abstract void print();
	abstract void addItem();
	 abstract void checkIn();
	  abstract void checkOut();
		Item() {
			
		}
		public Item(int id, String title, int noOfCopies) {
			super();
			this.id = id;
			this.title = title;
			this.noOfCopies = noOfCopies;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public int getNoOfCopies() {
			return noOfCopies;
		}
		public void setNoOfCopies(int noOfCopies) {
			this.noOfCopies = noOfCopies;
		}
		
	
}

 abstract class WrittenItem  extends Item {
	 String author;
	 
	 
	 
	
}
 class Book extends WrittenItem {
	 void print() {
		 System.out.println("library bokk bill is printed");
	 }
		 void addItem() {
			 System.out.println("book added in library");
		 }	
		
		  void checkIn() {
			 System.out.println("student checkin for a book");
		 } 
		
		  void checkOut(){
			  System.out.println("check out for a book");
			 }  
		  }
 
class JournalPaper extends WrittenItem {
	private int yearOfPublish;
	 void print() {
		 System.out.println("library paper bill is printed");
	 }
		 void addItem() {
			 System.out.println("paper added in library");
		 }	
		
		  void checkIn() {
			 System.out.println("student checkin forpaper");
		 } 
		
		  void checkOut(){
			  System.out.println("check out for a paper");
			 }  
		  }
	 
 
 abstract class MediaItem  extends Item {
	
}
 class CD extends MediaItem {
	 private  String artist;
	 private String genre;
	 void print(){
		 System.out.println("cd is returned");
	 }
	 void addItem(){
		 System.out.println("cd added in library");
	 }
	 void checkIn(){
		 System.out.println("checkin for cd");
	 }
	 void checkOut(){
		 System.out.println("checkout for a cd");
	 }
	 
 }
 class Video extends MediaItem {
	 private String director;
	 private String genre;
	 private int yearReleased;
	 void print(){
		 System.out.println("video is returned");
	 }
	 void addItem(){
		 System.out.println("video added in library");
	 }
	 void checkIn(){
		 System.out.println("checkin for video");
	 }
	 void checkOut(){
		 
		 System.out.println("checkout for video");
	 }
	 
 }
 
 
public class labbook2 {

	public static void main(String[] args) {
	//	Book b=new Book();
		//WrittenItem w=new Book();
		Item i=new Book();
		i.addItem();
		i.checkIn();
		i.checkOut();
	//	JournalPaper j=new JournalPaper();
		i=new JournalPaper();
		i.addItem();
		i.checkIn();
		i.checkOut();
		i=new CD();
		i.addItem();
		i.checkIn();
		i.checkOut();
		i=new Video();
		i.addItem();
		i.checkIn();
		i.checkOut();
		
	}

}

