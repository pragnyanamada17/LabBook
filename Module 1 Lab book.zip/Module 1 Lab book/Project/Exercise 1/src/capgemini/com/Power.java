package capgemini.com;

import java.util.Scanner;

public class Power {
	void powerNum()
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter n");
	int n=sc.nextInt(); 
	        if(n>0)
	        {
	            while(n%2 == 0)
	            {
	                n/=2;
	            }
	            if(n == 1)
	            {
	               System.out.println("n is power of 2");
	            }
	        }
	        if(n == 0 || n != 1)
	        {
	            System.out.println("n is not power of 2");
	        }
	       
	     

}
	public static void main(String args[])
	{
		Power pow=new Power();
		pow.powerNum();
	}
}
