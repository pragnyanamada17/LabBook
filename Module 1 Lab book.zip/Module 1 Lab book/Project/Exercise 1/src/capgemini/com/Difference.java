package capgemini.com;

import java.util.Scanner;

public class Difference 
{
		void calculateDifference()
		{
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter n");
         int n=sc.nextInt();
         int k=(n*(n+1)/2)*(n*(n+1)/2);
           int l=n*(n+1)*(2*n+1)/6;
          int m=l-k;
         System.out.println(m);
         
}
public static void main(String args[])
{
	Difference dif=new Difference();
	dif.calculateDifference();
}
}


		  
		  
		  
		  
		  
		


