package exercise9;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class ExTimer implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Timer : "+java.time.LocalTime.now());
	}
	
}
public class TimerEx {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ExTimer t=new ExTimer();
		ExecutorService ex=Executors.newFixedThreadPool(1);
		while(true)
		{
			ex.execute(t);
			Thread.sleep(10000);
		}
		
	}

}
