package exercise8;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
public class CopyDataThread extends Thread
{
	 public CopyDataThread(FileInputStream f1, FileOutputStream f2)throws IOException,InterruptedException
	 {
		int k=0,c=0;
		while((k=f1.read())!=-1)
		{
			System.out.println((char)k);
			f2.write((char)k);
			c=c+1;
			if(c==10)
			{
				System.out.println("10 characters are copied");
				Thread.sleep(5);
				c=0;
			}
			
		}
		
	}
	  
}
