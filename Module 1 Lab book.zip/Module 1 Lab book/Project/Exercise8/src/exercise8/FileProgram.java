package exercise8;
import java.io.*;
public class FileProgram 
{
  public static void main(String[] args) throws 
IOException, InterruptedException
  {
	  FileInputStream f1=null;
	  FileOutputStream f2=null;
	  f1=new FileInputStream("d:\\example.txt");
	  f2=new FileOutputStream("d:\\newfile.txt");
	  CopyDataThread c=new CopyDataThread(f1,f2);
  }
}
