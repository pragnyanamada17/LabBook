package exercise7;
import java.util.*;

public class DuplicateNumber {
   public int[]  ModifyArray(int[] a)
    {
    	TreeSet<Integer> t=new TreeSet<Integer>();
    	for(int i=0;i<(a.length);i++)
    	{
    		t.add(a[i]);
    	}
    	System.out.println(t);
    	TreeSet<Integer> r = (TreeSet<Integer>)t.descendingSet();
		int[] b = r.stream().mapToInt(Integer::intValue).toArray();
    	return b;
    }
public static void main(String[] args)
	{
      Scanner sc=new Scanner(System.in);
      System.out.println("enter size");
      int n=sc.nextInt();
      System.out.println("Enter array elements");
      int a[]=new int[n];
      for(int i=0;i<n;i++)
      {
    	  a[i]=sc.nextInt();
      }
      DuplicateNumber m=new DuplicateNumber();
      int[] b=m.ModifyArray(a);
      System.out.println("elements in descending order:");
      for(int i=0;i<n-1;i++)
      {
    	  System.out.println(b[i]);
      }
	}
}
	

