package exercise7;
import java.util.*;

public class ListEx {
public List<Integer> votersList(HashMap<Integer,Integer> h)
		{
	        Set kv1=h.entrySet();
	        Iterator it1=kv1.iterator();
	        while(it1.hasNext()){
	     	Map.Entry entry=(Map.Entry)it1.next();
	     	if((Integer)entry.getValue()<18)
	     	{
	     		   it1.remove();
	     	}
	        }
			ArrayList<Integer> l=new ArrayList<Integer>(h.keySet());
			return l;
		    
		}
		public static void main(String[] args)
		{
	     HashMap<Integer,Integer> hm =new HashMap<Integer,Integer>();
	     hm.put(101, 18);
	     hm.put(102, 28);
	     hm.put(103, 8);
	     hm.put(104, 38);
	     hm.put(105, 88);
	     ListEx a=new ListEx();
	     System.out.println("Eligible to vote id numbers:"+a.votersList(hm));
		}

	}

