package exercise7;
import java.util.*;

public class SecondSmallest {
	public int getSecondSmallest(int a[]){
			List<int[]> list=Arrays.asList(a);
			Arrays.sort(a);
			return a[1];
			
		}
			public static void main(String[] args) {
				int n;
				SecondSmallest e=new SecondSmallest();
				Scanner sc=new Scanner(System.in);
				System.out.println("enter n");
				n=sc.nextInt();
				int a[]=new int[n];
				for(int i=0;i<a.length;i++)
					a[i]=sc.nextInt();
				System.out.println("second smallest number is:" +e.getSecondSmallest(a));

			}

		}
		



