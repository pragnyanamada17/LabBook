package exercise5.com;

import java.util.Scanner;

public class Handling {
	void trafficLights()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("select the color");
		String color=sc.next();
		if(color.equals("red"))
		System.out.println("Stop");
		else if(color.equals("Yellow"))
			System.out.println("Ready to go");
		else if(color.equals("Green"))
		System.out.println("Go");
		else
			System.out.println("");
		}	
		public static void main(String args[])
		{
			Handling han=new Handling();
			han.trafficLights();
		}
}
	


